import React from 'react'

const Button = React.forwardRef((props, ref) => {

  const handledClick = () => {
    console.log('你点击了我');
  }

  return (
    <>
      <input ref={ref}/>
      <button onClick={handledClick}>点击我</button>
    </>
  )
})

export class Form extends React.Component {

  inputRef = React.createRef()

  handledClick = () => {
    console.log('你点击了我');
  }

  setInputValue = (value) => {
    this.inputRef.current.value = value
  }

  render() {
    return (
      <>
        <input ref={this.inputRef}/>
        <button onClick={this.handledClick}>点击我1</button>
      </>
    )
  }
}

export default Button

