import React, { useRef } from 'react';
import './App.css';
import Button, {Form} from './Button'

function App() {

  // const createref = React.createRef();
  const useref = useRef(null);
  const inputRef = React.createRef();


  // fetch(`/api`)
  // .then(res => res.json())
  // .then(console.log)

  return (
    <div className="App">
      {/* <Button ref={useref}/> */}
      <input ref={inputRef}></input>
      <Form ref={useref} name={"suxi"}/>
      {/* <button ref={useref}>原生btn</button> */}

      <button onClick={() => {useref.current.setInputValue(inputRef.current.value)}}>实例</button>
    </div>
  );
}

export default App;
