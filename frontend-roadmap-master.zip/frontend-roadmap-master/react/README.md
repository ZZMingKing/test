# REACT

## hooks

1.1 如何使用 hook 去管理组件内部状态 - useState vs this.setState
1.2 如何使用 hook 简化组件实现(更易理解)
2. 如何通过 hook 使逻辑在组件之间复用
3. hook 规则