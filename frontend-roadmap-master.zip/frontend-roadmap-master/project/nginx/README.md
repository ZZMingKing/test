# NGINX 

## 代理
- 正向代理(Forward Proxy)
- 反向代理(Reverse Proxy)

`ps aux` - 打印所有进程
`ps aux | grep nginx`  - 打印nginx所有进程

nginx master-slave
master process: 监听管理工作进行
work process: nginx 实例

## 应用
- Web Server as Reverse Proxy
- Load Balance 