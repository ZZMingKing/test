#1. back-end instance1
docker run --name server1 -p 3001:3001 --env SERVER_NAME=server1 nginx-backend 

#2. back-end instance2
docker run --name server2 -p 3002:3001 --env SERVER_NAME=server2 nginx-backend

#3. front-end with nginx
docker run -p 3000:80 -v C:/Users/Lenovo/Desktop/frontend-roadmap/project/nginx/nginx/nginx.conf:/etc/nginx/nginx.conf --link server1:server1 --link server2:server2 nginx-frontend

