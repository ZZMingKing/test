const express = require('express')
const app = express()

app.get('/hello', function (req, res) {
  console.log('Server', process.env.SERVER_NAME, '/hello')
  res.json({
    data: `hello suxi`,
  })
})

app.listen(3001)