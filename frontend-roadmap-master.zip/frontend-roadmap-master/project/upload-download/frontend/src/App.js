import { useEffect, useRef, useState } from "react";
import "./App.css";

function App() {
  const fileRef = useRef();

  const [files, setFiles] = useState([]);
  const [type, setType] = useState("download");

  const fetchFiles = () => {
    fetch("/api/files", {
      method: "GET",
    })
      .then(res => res.json())
      .then(data => {
        setFiles(data.files);
      });
  };

  const handleUpload = () => {
    const files = fileRef.current.files;
    const [uploadFile] = files;

    const data = new FormData(); // 表单数据
    // 一切皆文件
    data.append("file", uploadFile);

    fetch("/api/upload", {
      method: "POST",
      body: data,
    }).then(() => {
      fetchFiles();
    });
  };

  // const handleDownload = id => {
  //   fetch(`/api/download?id=${id}`, {
  //     method: "GET",
  //   });
  // };

  useEffect(() => {
    fetchFiles();
  }, []);

  return (
    <>
      <div>
        <p>服务器文件资源</p>

        {files.map(file => (
          <div onClick={() => setType(type === "download" ? "preview" : "download")}>
            {type}:
            <span
              key={file + type}
              onClick={e => {
                e.stopPropagation();
                window.open(`/api/download?id=${file}&type=${type}`, "target");
              }}
            >
              {" "}
              {file}
            </span>
          </div>
        ))}
      </div>
      <br />
      <div>
        <label for="avatar">原生文件上传：</label>
        <input
          ref={fileRef}
          type="file"
          id="file"
          name="file"
          // accept="image/png, image/jpeg"
        ></input>
        <button onClick={handleUpload}> 上传文件 </button>
      </div>
    </>
  );
}

export default App;
