const express = require("express");
const busboy = require("busboy");
const shortid = require("shortid");
const { Readable: ReadableStream } = require("stream");

const server = express();

const binaryBucket = {};

server.get("/ping", (reqeust, response) => {
  console.log("测试 http 请求", reqeust);

  response.setHeader("Content-Type", "application/json");

  return response.send("pong");
});

// 1. request 中获取图片数据
// 2. 图片数据 得到其他信息 { mimeType, length, name, ...}
// 3. 存入 DB
server.post("/upload", (req, res) => {
  const uid = shortid.generate();
  // 解析 form-data(二进制/流数据)
  const bb = busboy({ headers: req.headers });

  req.pipe(bb);

  bb.on("file", (name, stream, info) => {
    const { filename, encoding, mimeType } = info;
    console.log(
      `文件 [${name}]: 文件名: ${filename}, 编码格式: ${encoding}, 文件类型: ${mimeType}`,
    );

    stream.on("data", data => {
      console.log(`文件 [${name}] 长度 ${data.length} 字节`);

      binaryBucket[uid] = {
        data: data, // [uint8]
        stream: stream, // 流对象
        filename: filename, // 文件名
        mimeType: mimeType, // 文件类型
      };
    });
  });

  return res.send({ id: uid });
});

server.get("/download", async (req, res) => {
  let { id, type = "download" } = req.query;

  const resource = binaryBucket[id];

  if (resource) {
    const { data, filename, mimeType } = resource;

    res.setHeader("Content-Type", mimeType);
    if (type === "download") {
      res.setHeader("Content-Disposition", `attachment; filename=${filename}`);
    }

    const readableStream = await ReadableStream.from(data);

    return readableStream.pipe(res).status(200);
  }
});

server.get("/files", (req, res) => {
  return res.send({
    files: Object.keys(binaryBucket),
  });
});

const port = "3001";
server.listen(port, () => {
  console.log(`server started on port ${port}`);
});
