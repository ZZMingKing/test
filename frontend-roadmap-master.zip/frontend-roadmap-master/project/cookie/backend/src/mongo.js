const { MongoClient } = require("mongodb");

const url = "mongodb://localhost:27017";
const client = new MongoClient(url);

const connect = async () => {
  await client.connect();
  console.log("Connected successfully to server");
  const db = client.db("cookie");

  const find = (collectionName, query) => {
    return db
      .collection(collectionName)
      .find(query)
      .toArray()
      .then(([user]) => user);
  };

  return {
    find,
  };
};

exports.connect = connect;
