const express = require("express");
const app = express();
const { connect } = require("./mongo");
const cookieParser = require("cookie-parser");

app.use(express.json());
app.use(cookieParser());

const seesion = {};

app.post("/login", async function (req, res) {
  const { username, password } = req.body;

  const user = await connect().then(({ find }) => {
    return find("users", {
      name: username,
      password: password,
    });
  });

  if (!user) {
    return res.status(401).send();
  }

  const { id, name, sex } = user;
  res.cookie("uid", user.id, {
    httpOnly: true,
    expires: new Date(new Date().getTime() + 600000),
  });

  seesion[id] = {
    name,
    sex,
  };

  res.send("登录成功");
});

app.post("/logout", (req, res) => {
  const { uid } = req.cookies || {};

  if (uid) {
    res.cookie("uid", "");
    delete seesion[uid];
  }

  res.end();
});

app.get("/user", function (req, res) {
  const { uid } = req.cookies || {};

  const user = seesion[uid];

  if (!user) {
    return res.status(403).send();
  }

  res.send(user);
});

app.get("/users/:uid", (req, res) => {
  const { uid } = req.params;

  connect()
    .then(({ find }) => {
      return find("users", uid);
    })
    .then(user => {
      console.log("user:", user);
    });

  res.end();
});

app.listen(3000);
