# Cookies

## Tech

- Vanilla JavaScript
- HTML
- Tailwind
- Axios
- Webpack ext
