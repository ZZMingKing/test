const axios = require("axios");

const apiInstance = axios.create();

apiInstance.interceptors.response.use(
  res => res,
  error => {
    console.log("response", error.response);
    if (error.response && error.response.status === 401) {
      document.getElementById("login-failed").classList.remove("hidden");
      setTimeout(() => {
        document.getElementById("login-failed").classList.add("hidden");
      }, 1000);
    }
    if (error.response && error.response.status === 403) {
      // 重定向至登录页
    }
  },
);

const login = () => {
  const username = document.getElementById("username");
  const password = document.getElementById("password");

  apiInstance({
    method: "post",
    url: "/api/login",
    data: {
      username: username.value.trim(),
      password: password.value.trim(),
    },
  });
};

window.onload = () => {
  const { theme } = document.cookie.split(";").reduce((prev, cur) => {
    const [key, value] = cur.split("=");
    prev[key] = value;
    return prev;
  }, {});

  if (theme) {
    [
      ...document.getElementsByTagName("body"),
      ...document.getElementsByTagName("h1"),
      ...document.getElementsByTagName("label"),
    ].forEach(e => e.classList.add(theme));
  }

  const btn = document.getElementById("login");
  btn.addEventListener("click", login);

  const userBtn = document.getElementById("get-user");
  userBtn.addEventListener("click", () => {
    apiInstance.get(`/api/user?timestamp=${new Date().getTime()}`).then(({ data }) => {
      alert(`用户信息: ${JSON.stringify(data)}`);
    });
  });

  const logoutBtn = document.getElementById("logout");
  logoutBtn.addEventListener("click", () => {
    apiInstance.post(`/api/logout`);
  });

  const dark = document.getElementById("dark");
  const light = document.getElementById("light");

  light.addEventListener("click", () => {
    document.cookie = "theme=light";
    [
      ...document.getElementsByTagName("body"),
      ...document.getElementsByTagName("h1"),
      ...document.getElementsByTagName("label"),
    ].forEach(e => {
      e.classList.add("light");
      e.classList.remove("dark");
    });
  });

  dark.addEventListener("click", () => {
    document.cookie = "theme=dark";
    [
      ...document.getElementsByTagName("body"),
      ...document.getElementsByTagName("h1"),
      ...document.getElementsByTagName("label"),
    ].forEach(e => {
      e.classList.add("dark");
      e.classList.remove("light");
    });
  });
};
