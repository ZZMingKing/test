# Cookie

## http/s 特点:

- 无状状态 (**Stateless**)

## Cookie 用处:

- 会话状态管理(**Stateful**)
- 个性化设置

## docker\*

- 镜像(image)
- 容器(container) - 实例化(启动)镜像
