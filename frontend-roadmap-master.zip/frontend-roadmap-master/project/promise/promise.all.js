// 调用 API1(耗时100ms) 和 API2(耗时200ms) 得到数据后同时打印 data1 和 data2

// 方式1: (耗时300ms)
let data1, data2;
fetch("/url1") // 100
  .then(data => {
    data1 = data;
  })
  .then(() => fetch("/url2"))
  .then(data => {
    data2 = data;
    console.log(data1, data2);
  });

// 方式2: (耗时200ms)
Promise.all([fetch("/url1"), fetch("/url2")]).then(([data1, data2]) => {
  console.log(data1, data2);
});
