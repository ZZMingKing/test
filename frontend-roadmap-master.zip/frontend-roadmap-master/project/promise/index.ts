// type PromiseStatus = "pending" | "fulfilled" | "rejected";

// type PromiseThen = (data: any) => Promise<any>;

function Promise1(executor) {
  this.PromiseState = "pending";
  this.PromiseResult = undefined;

  this.fulfilledCallback = [];
  this.rejectedCallback = [];

  const resolve = value => {
    this.PromiseResult = value;
    this.PromiseState = "fulfilled";

    const [callback] = this.fulfilledCallback?.splice(0, 1);

    if (callback) {
      const p = callback(this.PromiseResult);

      if (thenable(p)) {
        // duck type
        p.then(data => {
          resolve(data);
        });
      } else {
        resolve(p);
      }
    }
  };

  const reject = value => {
    try {
      this.PromiseResult = value;
      this.PromiseState = "rejected";

      const [callback] = this.rejectedCallback?.splice(0, 1);

      const p = callback(this.PromiseResult);

      // if (thenable(p)) {
      //   p.then(data => {
      //     resolve(data);
      //   });
      // } else {
      //   resolve(p);
      // }
    } catch (e) {
      reject(e);
    }
  };

  executor(resolve, reject);
}

Promise1.prototype.then = function (resolve, reject) {
  if (typeof resolve === "function") {
    this.fulfilledCallback.push(resolve);
  }
  if (typeof reject === "function") {
    this.rejectedCallback.push(reject);
  }

  return this;
};

Promise1.prototype.catch = function (reject) {
  Promise1.prototype.then(undefined, reject);
};

const thenable = o => {
  return o && typeof o.then === "function";
};

module.exports = Promise1;
