const Promise1 = require("./index.ts");

test("1. Promise 函数", () => {
  const p = new Promise1(resolve => resolve("bar"));

  p.then(value => {
    expect(value).toBe("bar");
  });
});

test("2. 测试自定义 Promise 函数", () => {
  const p = new Promise1(resolve => {
    setTimeout(() => {
      resolve("bar");
    }, 1000);
  });

  p.then(value => {
    expect(value).toBe("bar");
    return "baz";
  })
    .then(value => {
      expect(value).toBe("baz");
      return new Promise1(resolve => {
        setTimeout(() => {
          resolve("foo");
        }, 1000);
      });
    })
    .then(value => {
      expect(value).toBe("foo");
    });
});

test("3. 测试自定义 Promise 函数 reject", () => {
  const p = new Promise1((_, reject) => {
    setTimeout(() => {
      reject("error");
    }, 1000);
  });

  p.catch(error => {
    console.log("error", error);
    expect(error).toBe("error");

    return "success";
  }).then(value => {
    expect(value).toBe("success");
  });
});
