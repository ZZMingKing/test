import React, { useState } from "react";
import styles from "./index.module.css";
import { Input } from "antd";
import { MenuFoldOutlined } from "@ant-design/icons";

export default function Header(props) {
  const { links = [] } = props;

  const [menuOpen, setMenuOpen] = useState(false);

  const handleMenuOpen = () => {
    console.log(">>>>", menuOpen);
    setMenuOpen(!menuOpen);
  };

  return (
    <>
      <div className={styles.header}>
        <div className={styles.content}>
          <div className={styles.info}>
            <div className={styles.site}>Resposive Header</div>
            <div className={styles.links}>
              {links.map(link => (
                <a href="/xxxx">{link}</a>
              ))}
            </div>
          </div>
          <div className={styles.search}>
            <div className={styles.input}>
              <Input />
            </div>
            <div onClick={handleMenuOpen} className={styles["m-icon"]}>
              <MenuFoldOutlined />
            </div>
          </div>
        </div>
      </div>
      <div>
        <div
          className={`${menuOpen ? styles["menu-on"] : styles["menu-off"]} ${
            styles.menu
          }`}
        ></div>
      </div>
    </>
  );
}
