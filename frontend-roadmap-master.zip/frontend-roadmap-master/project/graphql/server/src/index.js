import { ApolloServer, gql } from "apollo-server";
import axios from "axios";

const typeDefs = gql`
  type User {
    id: Int!
    name: String!
    birthday: String!
    sex: String!
  }

  type Post {
    name: String!
    content: String!
    author: Int!
  }

  type DashBoard {
    user: User!
    posts: [Post!]!
  }

  type Query {
    hello: String
    user(uid: Int!): User
    users: [User!]!
    posts(uid: Int): [Post!]!
    postDashboard(uid: Int!): DashBoard
  }

  type Mutation {
    newPost(name: String!, content: String!, author: Int!): Post!
  }
`;

const resolvers = {
  Query: {
    hello: () => "hello world",
    user: async (parent, args, context, info) => {
      const { uid } = args;
      const {
        data: [user],
      } = await axios(`http://localhost:3000/users?id=${uid}`);
      return user;
    },
    users: async (parent, args, context, info) => {
      const { uid } = args;
      const { data: users } = await axios(`http://localhost:3000/users`);
      return users;
    },
    posts: async (parent, args, context, info) => {
      const { uid } = args;
      if (uid) {
        const { data: posts } = await axios(`http://localhost:3000/posts?author=${uid}`);
        return posts;
      }
      const { data: posts } = await axios(`http://localhost:3000/posts`);
      return posts;
    },
    postDashboard: async function (parent, args, context, info) {
      const user = await this.user(parent, args, context, info);
      const posts = this.posts(parent, args, context, info);
      return {
        user,
        posts,
      };
    },
  },
  Mutation: {
    newPost: async (parent, args, context, info) => {
      const post = { ...args };
      const response = await axios.post("http://localhost:3000/posts", {
        id: args.author + args.name,
        ...args,
      });
      if (response.status === 201) {
        return post;
      }
      return new Error("创建文章失败");
    },
  },
};

const server = new ApolloServer({
  typeDefs,
  resolvers,
  tracing: true,
});

server.listen().then(({ url }) => {
  console.log(`Server ready at ${url}`);
});
