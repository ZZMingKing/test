# 前端学习路径

> 注意事项 🚧：
>
> 1. 如果已学习掌握请 ☑️ 上对应知识点。
> 2. 知识点属于不同分组标签用【xxx】表示，当前包含标签: `【JavaScript】`、`【CSS】`、`【HTML】`、`【Book】`、`【Web】`、`【NodeJS】`

## 基础知识

- [ ] ⭐️【Book】[深入浅出 HTML5 编程](https://book.douban.com/subject/19894872/): 对现代 Web 编程基础概念认知

- [x] ⭐️【Book】[图解 HTTP](https://book.douban.com/subject/25863515/): 掌握 HTTP/s 协议、前后端请求通信方式等

  - http 报文格式
  - http 请求方式, 请求参数与请求体区别
  - http 各状态码含义
  - http/https 区别

- [x] ⭐️【CSS】设置页面元素布局

  - [Flex box](https://css-tricks.com/snippets/css/a-guide-to-flexbox/#aa-flexbox-properties) 布局：
    1. 行(列)元素居中显示;
    2. 元素填充空白区域()
  - [Position](https://www.ruanyifeng.com/blog/2019/11/css-position.html) 定位布局
  - [Float](https://www.runoob.com/css/css-float.html) 浮动布局

- [x] ⭐️⭐️【JavaScript】`this` 指向问题

  - 在全局执行环境中 `this` 指向全局对象 `Window` | `Global`
  - 构造函数(`constructor`)中的 `this` 指向构造的实例对象
  - 对象.属性值为函数(非箭头函数)调用时 `this` 指向对象自身, `DOM` 事件中回调函数的 `this` 指向元素实例
  - 箭头函数本身没有 `this` 对象，访问 `this` 指向的是箭头函数定义时上层作用域中的 this, 如：

    ```javascript
    const obj = {
      printFn: function () {
        console.log(this);
      },
      printArrow: () => {
        console.log(this);
      },
    };
    console.log(obj.printFn()); // 为 obj 非 window
    console.log(obj.printArrow()); // 为 window 非 obj

    // 转译成 es5 后的代码：
    var _this = this;
    var obj = {
      printFn: function printFn() {
        console.log(this);
      },
      printArrow: function printArrow() {
        console.log(_this);
      },
    };
    ```

  - Function.prototype.[xxx]: [`call`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Function/call), [`apply`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Function/apply), [`bind`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Function/bind) 可更改调用时 `this` 值
  - 测试: **[this Quiz](./scripts/this.js)**

- [x] ⭐️ 【JavaScript】软件包(JavaScript package)

  - package.json 文件
    > 在 JavaScript 项目中通过声明 `package.json` 来定义软件包, 并通过诸如 `npm` 等工具来管理软件包, 在项目中可执行 `npm init [-y]` 来创建 `package.json` 文件.
  - [package.json 属性](https://docs.npmjs.com/cli/v7/configuring-npm/package-json)
    - name: 软件包名(`[group]/name`).
    - version: 软件包的版本`主版本.次版本.补丁号`( [semver](https://semver.org/lang/zh-CN/#%E8%AF%AD%E4%B9%89%E5%8C%96%E7%89%88%E6%9C%AC-200) 规范)
    - main: `main` 指定一个软件包的入口文件, 如果用户导入某个包那么将执行该包的主文件并导出定义的对象
    - scripts: `scripts` 定义可使用 `npm run name` 执行的脚本
    - dependencies: 定义软件包依赖(`npm install xxx`)
    - devDependencies: 定义软件包开发阶段依赖(`npm install --save-dev xxx`)
  - [npm cli](https://docs.npmjs.com/cli/v7/commands) 命令:
    - `npm init [-y]`: 生成 `package.json` 文件
    - `npm install [--save-dev] [name]`: 安装项目中所有依赖/新增依赖
    - `npm run xxx`: 执行 scripts 中定义的某个脚本
    - `npm link xxx`: 创建本地软连接, 链接一个本地包(非下载部署软件包)方便本地开发调试
    - `npx xxx`: 执行本地或远程一个软件包
    - `npm publish`: 发布软件包到远程(可被其他人下载使用)

- [x] ⭐️ 【JavaScript】[事件传递机制](https://codepen.io/woo_tommy_l/pen/gNZJeg)

  - 理解事件的捕获与冒泡
  - `e.stopPropagation()` 方法阻止在捕获和冒泡阶段中继续传播
  - 相关 API: [`e.preventDefault()`](https://developer.mozilla.org/zh-CN/docs/Web/API/Event/preventDefault)

- [ ] ⭐️⭐️ 【JavaScript】原型链

  - `prototype` 是函数对象的一个属性, 它是由该函数构造的对象的原型.
  - `__proto__` 是一个对象的内部属性, 指向该对象的原型，通过此 `Object.getPrototypeOf(o)` 也可获取原型, 如: `foo.__proto__ === Foo.prototype`
  - 原型链最终指向 `null`:
    ```javascript
    // 3. foo 对象原型 指向 Foo 原型对象
    foo.__proto__ === Foo.prototype;
    // 2. Foo 原型对象原型 指向 基础对象原型对象
    Foo.prototype.__proto__ === Object.prototype;
    // 1. 基础对象原型对象原型 指向 null，原型链结束
    Object.prototype.__proto__ === null;
    ```
  - ![prototype](./assets/prototype.jpeg)

- [ ] ⭐️ 【JavaScript】Promise

  - `Promise` 对象是现代 JavaScript 异步编程的基础模式, 它表示一个异步操作
  - `Promise` 对象通过 `.then` 方法执行异步回调, `.catch` 方法异常捕获, `then/catch` 均返回一个 `Promise` 对象可进行链式调用, eg: `fetch(...).then().catch().then()`
  - 使用 ES 原生 [`Promise()`](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Promise/Promise) 函数构造 `Promise` 对象，签名及用法
  - 各种社区 `Promise` 对象[扩展方法](https://github.com/sindresorhus/promise-fun)\*

- [ ] ⭐️⭐️ 【Web】CORS (跨域请求协议)

  - 默认出于安全性, `XHR` 与 `Fetch` 遵循[同源](https://developer.mozilla.org/en-US/docs/Web/Security/Same-origin_policy#definition_of_an_origin)策略, 这导致端口等不同时前端不能直接访问后端数据(开发中常用代理解决).
    ![](./assets/cors_error.png)
  - 我们可以通过在`服务端声明响应头`来指示哪些有权限访问服务器资源, 具体 `Reponse Header` 如下：
    ![](./assets/cors_res_header.png)
  - 什么是`预检(preflight)请求`: 默认跨域请求时`get/option`方法的请求可以直接发送，但请求为`post`或其它方法时需要向服务器提前发送预检请求(`method: option`, 由浏览器自动发送)来询问服务端是是否支持, 并携带以下`请求头`：
    ```http
    Access-Control-Request-Method: <method> (询问服务器是否支持该方法)
    Access-Control-Request-Headers: <header> (用于告知服务器哪些header将由客户端发出)
    ```

- [ ] ⭐️【JavaScript】模块系统 (module `CommonJS` & `ES`)

  - JavaScript 模块化发展历史 [一](http://www.ruanyifeng.com/blog/2012/10/javascript_module.html) [二](https://www.ruanyifeng.com/blog/2012/10/asynchronous_module_definition.html) [三](https://www.ruanyifeng.com/blog/2012/11/require_js.html)
  - 模块的加载机制 module loader.
  - CommonJS vs ES Module.
    - 动态/静态
    - 同步/异步
    - 循环依赖

- [ ] ⭐️【JavaScript】高阶函数 & 科里化

  - First-Class Function (头等函数)
    > 头等函数意味着：函数可以作为其他函数的参数、返回值，赋值给变量或存储在数据结构中。
  - High Order Functional (高阶函数)
    > 当一个函数接受另一个函数作为其参数或返回一个函数则该函数为高阶函数
  - [Curry Function](./scripts/high_order_function.js) (科里化函数)

- [ ] ⭐️【NodeJS】环境变量

  - 如何读取环境变量: `process.env`
  - 如何设置环境变量:

    - 如行 nodejs 程序时通过命令行设置:

      ```sh
      # 1. windows CMD:
      set [ENV_NAME]=[ENV_VALUE] && node xxx
      # 2. linux/mac
      export [ENV_NAME]=[ENV_VALUE] && node xxx

      # *使用 cross-env 处理系统差异：
      cross-env FIRST_ENV=one SECOND_ENV=two node xxx
      ```

    - 程序设置环境变量：
      ```js
      process.env.ENV_NAME = ENV_VALUE;
      ```

  - 环境变量作用:
    通过设置环境变量可快速对不同环境进行测试, 或进行相应打包构建策略等.
  - 相关 package:
    - [corss-env](https://www.npmjs.com/package/cross-env)
    - [dotenv](https://www.npmjs.com/package/dotenv)

- [ ] ⭐️⭐️⭐️ 【JavaScript】装饰器 [Decorator](./scripts/decorators/index.ts)

  > Decorator 是一个函数，用来修饰类、属性、方法、参数等允许您扩展其功能或添加元数据来对其进行注释
  > Decorator、Proxy 等都是`面向切面编程AOP(Aspect Oriented Programming)` 主要是为了把一些常用功能如权限检查、日志、事务等，从每个业务方法中剥离出来, 是代码更加易读和易维护.

  - IOC: Inversion of Control: 控制反转
  - DI: Dependency Injection: 依赖注入

- [ ] ⭐️ 【CSS】移动端设计

  > CSS 单位: px, x%, em, rem, vw, vh, pt
  > https://codesandbox.io/s/css-dan-wei-woyfk2?file=/index.html

  > 响应式设计 x 媒体查询：Resposive CSS x Media Queries

## 项目 Demo

- [文件上传下载](./project/upload-download)
- [HTTP Cookie](./project/cookie)
- [GraphQL](./project/graphql)
- [nginx with container](./project/nginx)
- [响应式组件设计](./project/resposive-header/)
