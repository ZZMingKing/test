// --------------------  #1  ------------------------
message = "sx";
const o = {
  message: "suxi",
  hi() {
    console.log(this.message);
  },
  hey: () => {
    console.log(this.message);
  },
};
o.hi(); // ???
o.hey(); // ???
const { hi } = o;
hi(); // ???

// --------------------  #2  ------------------------
function Person(name, age) {
  this.name = name;
  this.age = age;
  this.print = () => {
    console.log(this.name, this.age);
  };
}
const s = new Person("suxi", 18);
s.print(); // ???

// --------------------  #3  ------------------------
class A {
  constructor() {}

  foo() {
    function bar() {
      console.log("bar:", this);
    }
    const baz = () => {
      console.log("baz:", this);
    };
    bar();
    baz();
    console.log("foo:", this);
  }
}
const a = new A();
a.foo(); // ???

// --------------------  #4  ------------------------

function fn() {
  const printFn = function () {
    console.log(this);
  };
  const printArrow = () => {
    console.log(this);
  };

  console.log(printFn(), printArrow());
}

fn(); // ???

const obj = {
  fn: fn,
};
obj.fn(); // ???
