/* -------------------------- *****High Order Function***** -------------------------- */
// fn() => fn
// 初始化或者预定义的工作
// Model1, Model2
const log = (config, message) => {
  console.log(`[${config.name} info]: ${message}`)
}

// const m1Log = log({ name: "Model1"})
// const m2Log = log({ name: "Model2"})
log({ name: "Model1"}, "this is log from model 1")
log({ name: "Model2"}, "this is log from model 2")


/* -------------------------- *****Curry Function***** -------------------------- */
const {curry} = require("ramda")
function fn(a,b,c) {
  console.log(a,b,c);
}

const curryFn = curry(fn)

curryFn(1)(2)(3)

