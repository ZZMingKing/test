interface Repository {
  save: Function
  find: Function
}

const mysql: Repository = {
  save: () => { console.log('mysql save') },
  find: () => { console.log('mysql find') }
}

const ecs: Repository = {
  save: () => { console.log('ecs save') },
  find: () => { console.log('ecs find') }
}

class Person {
  repository = undefined;

  constructor() {
    this.repository = mysql
  }
  
  
  save() {
    this.repository.sage(this)
  }

  find(id) {
    this.repository.findOne(id)
  }
}

const sx = new Person();
sx.save();


/* -------------------------- ********** -------------------------- */