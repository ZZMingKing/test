const injector = {
  dependencies: {},
  register: function (key, value) {
    this.dependencies[key] = value;
  },
  resolve: function (deps, func, scope) {
    var args = [];
    for (var i = 0; i < deps.length, d = deps[i]; i++) {
      if (this.dependencies[d]) {
        args.push(this.dependencies[d]);
      } else {
        throw new Error('Can\'t resolve ' + d);
      }
    }
    return function () {
      func.apply(scope || {}, args.concat(Array.prototype.slice.call(arguments, 0)));
    }
  }
}

const service1 = () => { console.log('service1'); }
const service11 = () => { console.log('mock service1'); }
const service2 = () => { console.log('service2'); }
const service22 = () => { console.log('mock service2'); }

injector.register('service1', service1)
injector.register('service11', service11)
injector.register('service2', service2)
injector.register('service22', service22)

function fn(s1, s2) {
  s1();
  s2()
}


const callback = injector.resolve([process.argv[2], process.argv[3]], fn)
callback();
