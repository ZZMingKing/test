const NotLessThan = (num) => (property, name) => {
  var _value;
  Object.defineProperty(property, name, {
      enumerable: true,
      configurable: true,
      set(value) {
        if (value < num) {
          throw new Error(`err less then ${num}`)
        }
        _value = value
        console.log('set', _value)
      },

      get() {
        console.log('get', _value)
        return _value
      }
  });
}

class Person {
  constructor(name, age, phone) {
    this.id = Math.random().toString(16)
    this.name = name;
    this.age = age;
    this.phone = phone;
  }

  readonly id: string;
  
  name: string

  @NotLessThan(20)
  age: number

  phone: string
}

const sx = new Person('xxx', 20, 123456); // throw err age < 18
sx.age = 21
console.log('>>>', sx, sx.age)