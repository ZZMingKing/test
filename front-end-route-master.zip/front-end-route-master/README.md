# 前端学习仓库

## 介绍

个人前端学习路线汇总。


## 目录

javaScript基础系列

1. <a href="./basics/1.javaScript 基础简单总结.md">javaScript 基础简单总结</a>
2. <a href="./basics/2.javaScript执行机制.md">javaScript执行机制</a>
3. <a href="./basics/3.setTimeout和setInterval和promise和process.nextTick.md"> 3.setTimeout和setInterval和promise和process.nextTick</a>
4. <a href="./basics/4.变量和类型.md">变量和类型</a>
5. <a href="./basics/5.原型和原型链以及继承.md">原型和原型链以及继承</a>
